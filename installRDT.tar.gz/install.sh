git clone https://github.com/intel/intel-cmt-cat
mv intel-cmt-cat intel
cd intel
make
sudo make install
cd ..

